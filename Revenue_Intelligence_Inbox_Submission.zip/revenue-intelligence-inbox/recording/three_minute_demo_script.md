# Three-minute narrated screen recording script

**Target length:** 3:00. Record the running app in a desktop browser; show the cursor and narrate naturally.

## 0:00–0:35 — Dashboard and inbox
“Revenue Intelligence Inbox turns call and meeting notes into an evidence-led review queue. The dashboard shows unique records, calls versus meetings, transcript coverage, and items needing human review. I can filter by source, route, review state, or search the text. The dataset is a one-day sample, not a representative sales-performance benchmark.”

**On screen:** open `index.html`; point to metrics; filter to “Needs review”; open one record.

## 0:35–1:20 — Difficult routing decision: M07
“Here M07 is not simply a generic product complaint. The updated transcript says a saved payment description remains unchanged and a document upload is blocked. I route it to Customer follow-up and leave it for review because the source shows the symptoms, not the technical root cause. I’m deliberately not inventing a cause or a deal value.”

**On screen:** search M07; read the evidence card; show route and review state. If the packaged seed's identifier has been renumbered in your local version, search for “payment description”.

## 1:20–2:00 — Manual correction and evidence
“C01 says the person did not ask for the call and is not interested. That is a contact-preference signal, not a normal follow-up. The route respects the preference and avoids repeat outreach. M01 mixes partner commission, customer pricing, and onboarding, so multiple teams may need to review it. The interface exposes the source evidence alongside the route so a reviewer can challenge it.”

**On screen:** search “didn't ask for this call”; show C01. Then search “commission”; show M01. Optionally save a manual route correction and note.

## 2:00–2:45 — Duplicate/update replay test
“Importing the same record ID at the same revision should not create a duplicate. A higher revision updates the source record. If a reviewer has explicitly overridden the route, that correction survives the higher-revision update. This keeps repeat imports safe and makes corrections durable.”

**On screen:** prepare two tiny JSON files, first `[{"id":"TEST-1","revision":1,"type":"Call","text":"Need a follow-up","route":"Follow-up","review":"New"}]`, then import it twice. Confirm the unique count increases only once. Import `[{"id":"TEST-1","revision":2,"type":"Call","text":"Updated text: customer asks for onboarding help","route":"Customer follow-up","review":"Needs review"}]`; show the revision changes and route override is retained if you manually changed it before import.

## 2:45–3:00 — Export and limits
“Finally, I export the current records as JSON or a CSV manifest. The included bundle also has route-organized JSON exports. Routing is deterministic and transparent; this is a triage assistant, not an autonomous CRM or a source of verified revenue forecasts.”

**On screen:** click Export all JSON and Export manifest CSV. End on the dashboard.

## Before recording
- Use a real screen recorder and microphone; verify the file plays and is approximately 3 minutes.
- The initial dataset includes illustrative placeholders besides the three evidence-led cases. State that caveat if showing aggregate counts.
- Test import using a JSON file saved locally. Avoid claiming a successful deployment until you publish the folder to a public static host.
