# Revenue Intelligence Inbox — submission bundle

## What is included
- `index.html`: self-contained interactive app (no build step, no external API).
- `demo-data/records.json`: seeded records for the demo.
- `exports/`: route-organized JSON records and `manifest.json` / `manifest.csv`.
- `Revenue_Intelligence_Inbox_5_Slides.pptx`: five-slide findings/decision deck.
- `recording/three_minute_demo_script.md`: narration, screen actions, and timestamps.
- `source/`: editable application source copy.

## Run locally
Open `index.html` in a modern desktop browser. For stricter browser settings, run `python -m http.server 8000` from this directory and open `http://localhost:8000`.

## Import, duplicate, update, correction
Use **Import JSON / CSV**. Records are keyed by stable `id`; a repeated or lower revision is ignored, while a higher `revision` updates source fields. A saved manual route override is preserved when a higher revision arrives. The demo uses browser localStorage, so data persists in that browser only. Use **Reset demo data** to restore the packaged seed.

## Important data caveat
Only the three evidence-led cases C01, M01, and M07 and the aggregate acceptance targets (44 records, 30 calls, 14 meetings; usable text 17/44 to 18/44 after the M07 update) were grounded in the provided brief/previous deck. The remaining records are explicitly illustrative seed rows because the original source archive was not available to this build process. Do not present illustrative rows as actual source findings. The supplied 5-slide deck is included as the editable presentation.

## Exports
The pre-generated route exports are a static snapshot. The live app can export the current browser state to JSON and CSV. Recreate route folders after edits by exporting JSON/CSV and sorting by the `route` field, or use the packaged export snapshot for review.

## Deployment
This bundle is ready for static hosting (GitHub Pages, Netlify, Cloudflare Pages, or equivalent). No public hosting credentials or deployment integration were available in this session, so no public deployed URL is claimed. Upload the folder contents to a static host and enable public access to obtain the required shareable link.

## Recording
No screen-capture or voice-recording capability was available in this session. Follow the provided 3-minute narration script to record the actual app workflow, including the duplicate/update test.
